# phoenix_sample
 
This is a simple elixir LiveView application, packaged up for drag and drop deployment through CapRover. The app includes the LiveDashboard performance dashboard.

Once deployed you need to turn on Websocket Support in Http Settings and map the HTTP Port to 4000.

The source code for this app is available for viewing here:
https://github.com/TehSnappy/phoenix_sample