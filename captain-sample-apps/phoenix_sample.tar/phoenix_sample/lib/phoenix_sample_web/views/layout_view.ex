defmodule PhoenixSampleWeb.LayoutView do
  use PhoenixSampleWeb, :view
end
