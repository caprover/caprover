defmodule SampleWeb.PageView do
  use SampleWeb, :view
end
