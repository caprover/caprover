defmodule SampleWeb.LayoutView do
  use SampleWeb, :view
end
