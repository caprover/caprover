defmodule SampleWeb.LayoutViewTest do
  use SampleWeb.ConnCase, async: true
end
