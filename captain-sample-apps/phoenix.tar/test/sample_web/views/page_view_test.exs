defmodule SampleWeb.PageViewTest do
  use SampleWeb.ConnCase, async: true
end
