ExUnit.start()

Ecto.Adapters.SQL.Sandbox.mode(Sample.Repo, :manual)

