<html>
 <head>
  <title>PHP Test</title>
 </head>
 <body>
 <?php echo '<p>Hello World from PHP running via Captain!</p>'; ?> 
 </body>
</html>
