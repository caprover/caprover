# laravel-caprover
Sample Laravel With CapRover. 

IMPORTANT:

Note that the build process for laravel projects are quite heavy, you need at least 2GB, or in some instances 4gb of RAM or your server might crash. 
