This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## CapRover files
The following files are added to make Create React App work with CapRover:

- `captain-definition`
- `Dockerfile`
- `default.conf`
